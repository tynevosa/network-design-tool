import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import 'bootswatch/dist/cosmo/bootstrap.min.css';
import Login from './pages/Login';
import DropTest from './pages/DropTest';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<><div className="App"><Login /></div></>} />
        <Route path="droptest" element={<DropTest />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
