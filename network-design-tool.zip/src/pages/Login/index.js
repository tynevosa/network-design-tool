import React from "react";
import NavBar from '../../layouts/NavBar';
import Entry from "../../components/Entry";
import NewLocation from "../../components/NewLocation";
import LocationView from "../../components/LocationView";

export default function Login() {
    const [currentPage, setCurrentPage] = React.useState('entry');
    return(
        <>
            <NavBar />
            {currentPage === 'entry' && (<Entry onNextPage={() => setCurrentPage('newlocation')}/>)}
            {currentPage === 'newlocation' && (<NewLocation onNextPage={() => setCurrentPage('locationview')}/>)}
            {currentPage === 'locationview' && (<LocationView onNextPage={() => setCurrentPage('moo')}/>)}
        </>
    );
}