import React, { useState, useRef } from "react"
import Draggable from 'react-draggable'

function DropTest() {
  const [isDragging, setIsDragging] = useState(false)
  const [image1, setImage1] = useState({x:0,y:0})
  const [image2, setImage2] = useState({x:0,y:0})
  const slotRef = useRef()
  const imgRef = useRef()
  const [slots, setSlots] = useState(Array(12).fill(''))

  const dragggingStyle = {
    width: "380px",
    height: "35px",
    border: isDragging && "1px solid #2342ab",
    borderStyle: isDragging && "dotted",
    zIndex: isDragging && "1"
  }

  const handleDragStart = (e, data) => {
    setIsDragging(true)
    e.target.style.zIndex = '20000'
  }
  var slot = -100
  var magnet = false
  var posX = 0
  var posY = 0
  const handleDragging = (e, data) => {
    var rect = e.target.getBoundingClientRect()
    var x = window.scrollX + rect.left
    var y = window.scrollY + rect.top
    var refX = slotRef.current.offsetLeft+8
    var refY = slotRef.current.offsetTop+8
    if (Math.abs(x-refX) < 380){
      if (Math.abs(y-refY) < 385){
        let regionY = Math.round((y-refY)/35)
        if(regionY>=0 && regionY<12 && slot !== regionY){
          slot = regionY
          posY = slot*35+8
        }
        if (Math.abs(x-refX) < 30){
          if(magnet === false){
            magnet = true
            posX = slotRef.current.offsetLeft - imgRef.current.offsetLeft + 8
          }
        } else {
          if(magnet){
            magnet = false
          }
        }
      }
    }
  }
  const handleDragStop = (e, data) => {
    setIsDragging(false)
    e.target.style.zIndex = '10000'
    if(slot<0 || !magnet) return
    var newSlots = [...slots]
    if(e.target.id === "obj-abcdef"){
      if(newSlots[slot]!=='') return
      for (let index = 0; index < newSlots.length; index++) {
        if(newSlots[index] === "obj-abcdef"){
          newSlots[index] = ""
        }
      }
      newSlots[slot] = e.target.id
      setSlots(newSlots)
      setImage1({x:posX, y:posY})
    }
    if(e.target.id === "obj-xyzefg"){
      if ( slot > 2 ) return
      for (let index = slot; index < slot+10; index++) {
        if(newSlots[index] === "obj-abcdef"){
          return
        }
      }
      for (let index = 0; index < newSlots.length; index++) {
        if(newSlots[index] === "obj-xyzefg"){
          newSlots[index] = ""
        }
      }
      for (let index = slot; index < slot+10; index++) {
        newSlots[index] = "obj-xyzefg"
      }
      setSlots(newSlots)
      setImage2({x:posX, y:posY-35})
    }
    posX = 0 ; posY = 0
    magnet = false
    slot = -100
  }

  return (
    <div style={{display: "flex", margin: "8px"}}>
      <div id="leftSide" style={{display: "flex"}}>
        <div id="obj-a23abc" className="ui-widget-content draggable SizeToParent ui-draggable ui-draggable-handle" style={{width: "480px", height: "950px", backgroundImage: "url('assets/images/24u_test_cab2.png')", backgroundSize: "100% 100%", zoom: "1", position: "relative", paddingLeft: "50px", paddingRight: "50px", paddingTop: "65px"}}>
          <div ref={slotRef} id="slot">
          {slots.map((i, index) => {
            return(
              <div key={index} id="zone-df3ds" style={dragggingStyle} className="droppable ui-droppable" data-dropclass="class-19inRackMount otherTestClass">
              </div>
            )
          })}
          </div>
        </div>
      </div>
        <div id="center" style={{marginLeft: "auto"}}>
          <div className={`droppable multiDrop ui-droppable`} style={{width: "500px", height: "500px"}}>
          </div>
        </div>
      <div id="rightside" style={{marginLeft: "auto", width: "400px", backgroundColor: "#b4fcff"}} className="droppable multiDrop ui-droppable ui-droppable-disabled">
        <p></p><center><b>VIRTUAL WORKBENCH</b></center><p></p>
        <div style={{listStyleType: "none"}}>
          <Draggable
            position={image1}
            onStart={(e, data) => handleDragStart(e, data)}
            onDrag={(e, data) => handleDragging(e, data)}
            onStop={(e, data) => handleDragStop(e, data)}>
            <div ref={imgRef} id="obj-abcdef" className="ui-widget-content draggable SizeToParent ui-draggable ui-draggable-handle" data-dragclass="class-19inRackMount" style={{width: "380px", height: "35px", backgroundImage: "url(assets/images/UDM-SE.png)", backgroundSize: "100% 100%", zoom: "1", position: "relative", left: "0px", top: "0px"}}>
            </div>
          </Draggable>
          <Draggable
            position={image2}
            onStart={handleDragStart}
            onDrag={handleDragging}
            onStop={handleDragStop}>
            <div id="obj-xyzefg" className="ui-widget-content draggable SizeToParent ui-draggable ui-draggable-handle" data-dragclass="class-19inRackMount" style={{width: "380px", height: "350px", backgroundImage: "url(assets/images/m1000e.png)", backgroundSize: "100% 100%", zoom: "1", position: "relative", left: "0px", top: "0px"}}>
            </div>
          </Draggable>
        </div>
      </div>
    </div>
  )
}

export default DropTest