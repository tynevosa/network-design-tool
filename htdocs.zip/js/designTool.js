$( function() {
// Start jQuery


	$("#startToolNew").click(function() {
		$("#entryPoint").hide();
		$("#newLocWidget").show();
	});

	$("#addEnclosure").click(function() {
		$("#newLocWidget").hide();
		$("#locationView").show();
	});
	
	$(".enclosureItem").hover(function() {
		$(this).addClass("encHover");
	}, function() {
		$(this).removeClass("encHover");
	});
	
	$(".enclosureItem").click(function() {
		$(this).removeClass("encHover");
		$("#locationView").hide();
		$("#moo").show();
	});
	
// End jQuery		
});