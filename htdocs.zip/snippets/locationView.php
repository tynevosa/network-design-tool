<div id="locationView" class="w-100 h-100" style="display: none;">
	<div class="row h-100 d-flex justify-content-center align-items-center">
		<div id="encl-abcxyz" class="enclosureItem" style="width: 600px; height: 600px;border: 1px solid #b6b6b6; padding: 25px;">
			<div><h3 class='text-center'><b>24U Generic Cabinet</b></h3></div>
			<div style="background: url('24u_test_cab2.png') no-repeat;background-size: contain; background-position: center center; height: 90%;width: 100%;"></div>
		</div>
		<div id="encl-abcxyz" class="" style="margin-left: 50px;width: 600px; height: 600px;border: 1px solid #b6b6b6; padding: 25px;">
			<div><h3 class='text-center' style="margin-top: 50%; margin-bottom: 50%;"><b>( ADD ENCLOSURE )</b></h3></div>
		</div>
	</div>
</div>