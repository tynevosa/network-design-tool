    <div id="newLocWidget" class="w-100 h-100" style="display: none;">

		<div class="h-100 d-flex justify-content-center align-items-center">
			<div class="card border-primary mb-3" style="min-width: 600px; max-height: 800px;">
				<div class="card-header text-center"><h3>Select your first Object</h3></div>
				<div class="card-body" style="display: inline-flex;">
					<div style="width: 33.3%;padding-right: 20px;border-right: 1px dashed #333;" class="">

						<div class="row" style="heieght: 50px; border-bottom: 1px dashed #333; padding-bottom: 10px;" class="dp-5">

							<fieldset>
								<div class="form-group row" style="display: flex; align-items: center;  justify-content: center;">
									<p class="text-center">Choose initial container type</p>
									<!-- br>
									(Ex: Cabinets or Pole Mounts)<br -->
									<select class="form-select" id="newLocContainerType">
										<option value=1>19 Inch (Network) Rackmount</option>
										<option value=2>23 Inch (Telco) Rackmount</option>
										<option value=3>Pole & Tower Mounts and others</option>
									</select>
									<!-- input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" -->
								</div>
							</fieldset>
							
						</div>

						<div class="row" style="height: 100%; padding-top: 10px;" class="">
							<!-- div id="containers-0" style="height: 100%; height: 100%;" class="text-center">
							<br><br><br><br>
							To start, select a container type form the pulldown list above.
							</div-->
							<div id="containers-1" style="height: 100%; height: 100%;" class="text-center">
								<fieldset>
									<div class="form-group row" style="display: flex; align-items: center;  justify-content: center;">
										<input type="text" class="form-control" id="newLocRackSearchTxt" placeholder="Search for Rackmount Enclosures">
								</div>
								</fieldset>
							
								<ul class="gallery bjListGal ui-helper-reset" style="width: 100%;">
									<li style="">
										<div  style="display: inline-flex; height: 75px; width: 100%;padding: 5px; border: 1px solid #000;">
											<div  style="width: 30%; height: 100%;">
												<img src="24u_test_cab2.png" alt="The peaks of High Tatras" style="width: 100%; height: 100%;object-fit: contain;">
											</div>
											<div style="width: 70%; height: 100%;">
												<b>24U Generic Cabinet</b><br>
												Brand: Generic
											</div>
										</div>										
									</li>
									<li style="background-color: #ddeeff;">
										<div  style="display: inline-flex; height: 75px; width: 100%;padding: 5px; border: 1px solid #000;">
											<div  style="width: 30%; height: 100%;">
												<img src="24u_test_cab2.png" alt="The peaks of High Tatras" style="width: 100%; height: 100%;object-fit: contain;">
											</div>
											<div style="width: 70%; height: 100%;">
												<b>24U Generic Cabinet</b><br>
												Brand: Generic
											</div>
										</div>										
									</li>

									<li style="background-color: #ddeeff;">
										<div  style="display: inline-flex; height: 75px; width: 100%;padding: 5px; border: 1px solid #000;">
											<div  style="width: 30%; height: 100%;">
												<img src="24u_test_cab2.png" alt="The peaks of High Tatras" style="width: 100%; height: 100%;object-fit: contain;">
											</div>
											<div style="width: 70%; height: 100%;">
												<b>24U Generic Cabinet</b><br>
												Brand: Generic
											</div>
										</div>										
									</li>

									<li style="background-color: #ddeeff;">
										<div  style="display: inline-flex; height: 75px; width: 100%;padding: 5px; border: 1px solid #000;">
											<div  style="width: 30%; height: 100%;">
												<img src="24u_test_cab2.png" alt="The peaks of High Tatras" style="width: 100%; height: 100%;object-fit: contain;">
											</div>
											<div style="width: 70%; height: 100%;">
												<b>24U Generic Cabinet</b><br>
												Brand: Generic
											</div>
										</div>										
									</li>

								</ul>
								
								<!--ul id="galglery" class="gallery ui-helper-reset ui-helper-clearfix tn-gallery">
									<li class="ui-widget-content ui-corner-tr">
										<h5 class="ui-widget-header">High Tatras</h5>
											<img src="24u_test_cab2.png" alt="The peaks of High Tatras" width="96" height="72">
											<a href="24u_test_cab2.png" title="View larger image" class="ui-icon ui-icon-zoomin">View larger</a>
											<a href="link/to/trash/script/when/we/have/js/off" title="Delete this image" class="ui-icon ui-icon-trash">Delete image</a>
									</li>
								</ul -->
							</div>
						</div>



					</div>

					<div style="width: 66.6%;" class="row">
						<div style="width: 50%;" class="">
							<div id="newLocObjPreview" style="height: 100%; width: 100%;">
								<div style="background: url('24u_test_cab2.png') no-repeat;background-size: contain; background-position: center center; height: 100%;width: 100%;"></div>
							</div>
						</div>
	
						<div style="width: 50%;" class="">
							<div style="height: 80%;">
							Some details will go here.
							</div>
							<div>
								<button id="addEnclosure" type="submit" class="btn btn-primary" style="margin-top: 15px;">Add and Configure this Object</button>
							</div>
						</div>
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>