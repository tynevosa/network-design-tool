<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Network Design Tool</title>
		
		<link href="/css/cosmo.css" rel="stylesheet">
		<link rel="stylesheet" href="/css/local.css" >
		<style>
  .bjListGal { float: left; width: 65%; min-height: 12em; }
  .gallery.custom-state-active { background: #eee; }
  .gallery li { float: left; width: 100%; height: 75px; background-color: #77ccff; paddfing: 0.4em 0 0 0; margin: 0.4em 0 0 0; text-align: center; }
  .gallery li h5 { margin: 0 0 0.4em; curfsor: move; }
  .gallery li a { float: right; }
  .gallery li a.ui-icon-zoomin { float: left; }
  .gallery li img { width: 100%; curfsor: move; }
  .ui-widget-header {
    border: 1px solid #dddddd;
    background: #e9e9e9;
    color: #333333;
    font-weight: bold;
   }
   .ui-widget-content {
    border: 1px solid #dddddd;
    background: #ffffff;
    color: #333333;
    }
    .ui-helper-reset {
    margin: 0;
    padding: 0;
    border: 0;
    outline: 0;
    line-height: 1.3;
    text-decoration: none;
    font-size: 100%;
    list-style: none;
    }
		</style>
	</head>
		
	
	<body>
<?php include('snippets/navBar.php'); ?>
    <div id="topNoticeBar" class="w-100 hdf-100" style="display: none;">
		<div class="row g-0">
			<div class="col-lg-12">
			<center><b> EXTRA CRAP HERE </b></center>
			</div>
		</div>
	</div>
