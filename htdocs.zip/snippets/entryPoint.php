    <div id="entryPoint" class="w-100 h-100">
		<div class="h-100 d-flex justify-content-center align-items-center">
			<div class="card border-primary mb-3" style="min-width: 600px;">
				<div class="card-header text-center"><h3>Start a new Project</h3></div>
				<div class="card-body" style="display: inline-flex;">
					<div style="width: 50%;border-right: 1px dashed #333;" class="p-5">


						<h4 class="card-title text-center" style="min-width: 200px;">Name this Location</h4>
						<p class="card-text text-center" style="margin-bottom: 30px;">(You can change this later.)</p>
						<form>
							<fieldset>
								<div class="form-group row" style="display: flex; align-items: center;  justify-content: center;">
									<input type="text" class="form-control"  aria-describedby="locNameHelp" id="newLocName">
									 <small id="locNameHelp" class="form-text text-muted">Example: Main Building</small>
								</div>
 								<div class="form-group row">
									<button id="startToolNew" type="button" class="btn btn-primary" style="margin-top: 15px;">Start Designing</button>
								</div>

							</fieldset>
						</form>
						<div class="form-group row py-5" style="display: none;">
							<h3 class="text-center"><b> Sorry !</b></h3>
							Currently the site requries an account to operate.<br>
							Eventually local mode will be working correctly.<br>
							Logging in automatically saves all work and progress.<br>
							
							
						</div>
					</div>

					<div style="width: 50%;" class="p-5">
						<h4 class="card-title text-center">Login to Account</h4>
						<form>
							<fieldset>
								<div class="form-group row" style="display: flex; align-items: center;  justify-content: center;">
									<label for="exampleInputEmail1" class="form-label mt-4">Email address:</label>
									<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
								</div>
								<div class="form-group row">
									<label for="exampleInputPassword1" class="form-label mt-4">Password:</label>
									<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
								</div>
								
								<div class="form-group row">
									<button id="Login" type="submit" class="btn btn-primary" style="margin-top: 15px;">Log in</button>
								</div>
								
							</fieldset>
						</form>
						<div class="text-center"><br><br><h2><a href=/signup/><b>Sign up Here</b></a></h2></div>
					</div>
				</div>
			</div>
		</div>
	</div>