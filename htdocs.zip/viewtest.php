    <?php include('snippets/standardHeader.php'); ?>
    <?php include('snippets/entryPoint.php'); ?>
    <?php include('snippets/newLocationWidget.php'); ?>
    <?php include('snippets/locationView.php'); ?>
    
	
	<div id="enclosureLayout" class="w-100 h-100" style="display: none;">		
		<div class="row h-100 g-0">
			<div class="col-lg-3">
			<center><b> LEFT SIDE  HERE </b></center>
			</div>
		
			<div class="col-lg-6">
			<center><b> CENTER SIDE HERE </b></center>
			</div>
		
			<div class="col-lg-3">
			<center><b> RIGHT SIDE  HERE </b></center>
			</div>
		</div>
	
	</div>
	
	<?php include('snippets/standardFooter.php'); ?>